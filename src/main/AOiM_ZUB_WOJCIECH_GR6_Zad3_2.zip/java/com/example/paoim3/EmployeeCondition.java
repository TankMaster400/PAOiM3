package com.example.paoim3;

public enum EmployeeCondition {
    obecny,
    delegacja,
    chory,
    nieobecny;

    private EmployeeCondition() {
    }
}
